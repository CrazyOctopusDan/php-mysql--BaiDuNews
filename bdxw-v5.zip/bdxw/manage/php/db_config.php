<?php
	$db_name = "localhost";
	$db_id = "root";
	$db_pswd = "";
	$tb_name = "bd_news";
?>