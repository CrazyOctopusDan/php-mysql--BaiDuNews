$(document).ready(function(){
	// body...
	$('#submit_btn').click(function() {
		/* Act on the event */
		var userName = $('#user-id').val();
		var pswd = $('#user-pswd').val();
		if (userName == "admin" && pswd == "admin"){
			localStorage.setItem("username", "admin");
			window.location.href = "./manage.html";
		} else{
			alert("登录信息有误，请重试");
		}
	});
});